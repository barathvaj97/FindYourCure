import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PasswordValidator } from '../../register/register.validator';
import { doctorData } from '../../login/login.doctorData';
import { LoginService } from '../../login/login.service';
import { Router } from '@angular/router';
import { NavbarService } from '../../app.navbar.service';
import { browserRefresh } from '../../app.component';

@Component({
  selector: 'app-update-doctor',
  templateUrl: './update-doctor.component.html',
  styleUrls: ['./update-doctor.component.css']
})
export class UpdateDoctorComponent implements OnInit {

  errorMessage:string;
  successMessage:string;
  TheList:string[] = ["ent","cardiologist","gynocologist","dermatologist","endocrinologist","gastroenterologist","hematologist","nephrologist","oncologist"];
  doctorUpdateForm : FormGroup;
  private currentDoctorData: doctorData = new doctorData();
  isLoggedAsDoctor: boolean = false;

  constructor(private updateService:LoginService, private fb:FormBuilder,
              private navbarService:NavbarService, private router:Router) {
      this.navbarService.getDoctorLoginStatus().subscribe(status => this.isLoggedAsDoctor = status);
  }

  ngOnInit() {

    this.doctorUpdateForm=this.fb.group(
      {
        'did':[],
        'dname':['',[Validators.required,Validators.pattern("[a-zA-Z ]+")]],
        'yrsofexp':['',[Validators.required,Validators.min(1),Validators.max(99)]],
        'visithours':['',[Validators.required]],
        'visithoursend':['',[Validators.required]],
        'fee':['',[Validators.required]],
        'spc':['',[Validators.required]],
        'email':['',[Validators.required,Validators.email]],
        'password':['',[Validators.required,PasswordValidator.invalidPassword]]
      }
    );

    this.currentDoctorData=JSON.parse(localStorage.getItem("myDoctorData"));

    this.doctorUpdateForm.patchValue({
      did: this.currentDoctorData.did,
      dname: this.currentDoctorData.dname,
      yrsofexp: this.currentDoctorData.yrsofexp,
      visithours: this.currentDoctorData.visithours,
      visithoursend: this.currentDoctorData.visithoursend,
      fee: this.currentDoctorData.fee,
      spc: this.currentDoctorData.spc,
      email: this.currentDoctorData.email,    
      password: this.currentDoctorData.password,  
    });
    
    if(browserRefresh){
      this.navbarService.updateDoctorLoginStatus(true);
    }

    if(this.currentDoctorData==null){
      this.router.navigate(['/login']);
    }   
  }

  updateDoctor(){  
    this.errorMessage=null;
    this.successMessage=null;
    this.doctorUpdateForm.value.did = this.currentDoctorData.did;

    this.updateService.updateDoctor(this.doctorUpdateForm.value)
                      .then((response) => { this.successMessage = "Success";
                                              // alert("Doctor details has successfully been updated!");
                                          })
                      .catch((error) => { this.errorMessage = "Failure";
                                            // alert("Doctor details could not be updated!");
                                        });
                                        alert("Doctor details has successfully been updated!");
  }

}
