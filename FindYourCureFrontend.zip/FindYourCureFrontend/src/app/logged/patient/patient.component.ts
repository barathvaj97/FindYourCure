import { Component, OnInit } from '@angular/core';
import { patientData } from '../../login/login.patientData';
import { LoginService } from '../../login/login.service';
import { browserRefresh } from '../../app.component';
import { NavbarService } from '../../app.navbar.service';
import { PlatformLocation } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.css']
})

export class PatientComponent implements OnInit {

  private logPatientData: patientData = new patientData();
  isLoggedAsPatient: boolean = false;

  constructor(private navbarService:NavbarService, private router:Router,
              private location: PlatformLocation) {

      location.onPopState(() => {
        if( this.router.url=="/login" )
        {
          localStorage.removeItem('myPatientData');
        }
      }); 
  }
 

  ngOnInit() {

    this.logPatientData=JSON.parse(localStorage.getItem("myPatientData"));
   
    if(browserRefresh){
      this.navbarService.updatePatientLoginStatus(true);
    }

    if(this.logPatientData==null){
      this.router.navigate(['/login']);
    }      
  }
}
