import { Component, OnInit } from '@angular/core';
import { doctorData } from '../../login/login.doctorData';
import { LoginService } from '../../login/login.service';
import { browserRefresh } from '../../app.component';
import { NavbarService } from '../../app.navbar.service';
import { PlatformLocation } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-doctor',
  templateUrl: './doctor.component.html',
  styleUrls: ['./doctor.component.css']
})

export class DoctorComponent implements OnInit {

  private logDoctorData: doctorData = new doctorData();
  isLoggedAsDoctor: boolean = false;

  constructor(private navbarService:NavbarService, private router:Router,
              private location: PlatformLocation) {
      
      location.onPopState(() => {
        if( this.router.url=="/login" )
        {
          localStorage.removeItem('myDoctorData');
        }
      }); 
  }
  
  ngOnInit() {

    this.logDoctorData=JSON.parse(localStorage.getItem("myDoctorData"));

    if(browserRefresh){
      this.navbarService.updateDoctorLoginStatus(true);
    }

    if(this.logDoctorData==null){
      this.router.navigate(['/login']);
    }    
  }

}
