import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class ScheduleService {

  constructor(private http: Http) { }

  getDoctorList(data) :Promise<any>{
    return this.http
    .post("http://localhost:8765/FindYourCureBackend/FindYourCureAPI/getDoctorList1",data)
    .toPromise()
    .then(response => response.json() as any)
    .catch(this.errorHandler);
  }

  scheduleAppointment(data) :Promise<any>{
    return this.http
    .post("http://localhost:8765/FindYourCureBackend/FindYourCureAPI/scheduleAppointment",data)
    .toPromise()
    .then(response => response.json() as any)
    .catch(this.errorHandler);
  }

  getAppointmentList(did:any) :Promise<any>{
    return this.http
    .post("http://localhost:8765/FindYourCureBackend/FindYourCureAPI/getAppid/"+did, did)
    .toPromise()
    .then(response => response.json() as any)
    .catch(this.errorHandler);
  }

  getPatientDetails(appid:any) :Promise<any>{
    return this.http
    .post("http://localhost:8765/FindYourCureBackend/FindYourCureAPI/getPatientApp/"+appid, appid)
    .toPromise()
    .then(response => response.json() as any)
    .catch(this.errorHandler);
  }

  updateAppointment(data:any) :Promise<any>{
    return this.http
    .post("http://localhost:8765/FindYourCureBackend/FindYourCureAPI/updateAppointment", data)
    .toPromise()
    .then(response => response.json() as any)
    .catch(this.errorHandler);
  }

  errorHandler(error){
    return Promise.reject(error.json())
  }

}
