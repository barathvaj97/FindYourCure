import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ScheduleService } from '../schedule.service';
import { LoginService } from '../../login/login.service';
import { FetchService } from '../../admin/fetch.service';
import { NavbarService } from '../../app.navbar.service';
import { browserRefresh } from '../../app.component';
import { patientData } from '../../login/login.patientData';
import { doctorData } from '../../login/login.doctorData';
import { appointmentData } from '../../login/login.appointmentData';
import { AppList } from '../../login/login.appList';


@Component({
  selector: 'app-appointment-doctor',
  templateUrl: './appointment-doctor.component.html',
  styleUrls: ['./appointment-doctor.component.css']
})

export class AppointmentDoctorComponent implements OnInit {

  errorMessage: string;
  successMessage: string;
  isLoggedAsDoctor: boolean=false;
  private currentDoctorData: doctorData = new doctorData();
  private appPatientData: patientData = new patientData();
  private allDoctorList: doctorData[] = [];
  private appointmentList: appointmentData[] = null;
  private patDetailUpdate: patientData = new patientData();

  private appList: AppList[] = new Array();
  private buttonClicked: string;
  private appId: number;

  private newAppId: number;
  private newDocId: number;

  updateCureForm: FormGroup;
  appUpdateForm: FormGroup;
  getForm: FormGroup;

  constructor(private navbarService:NavbarService, private router:Router, private fb:FormBuilder,
              private scheduleService: ScheduleService, private loginService: LoginService, private fetchService: FetchService) {
    this.navbarService.getDoctorLoginStatus().subscribe(status => this.isLoggedAsDoctor = status);
  }


  ngOnInit() {

    this.currentDoctorData=JSON.parse(localStorage.getItem("myDoctorData"));

    this.fetchService.fetchDoctors()
        .then((response)=>{this.allDoctorList=response; 
      });

    this.getForm=this.fb.group({
        'sdoc':['',[Validators.required]]
    });

    this.scheduleService.getAppointmentList(this.currentDoctorData.did)
        .then((response)=>{ this.appointmentList=response;
                            let num = 0;
                            let appData: AppList;

                            for(let item of this.appointmentList){
                              
                              this.scheduleService.getPatientDetails(item.appid)
                                  .then((response)=>{ appData= new AppList();
                                                      appData.pat=response;

                                                      appData.itr= num+1;
                                                      
                                                      this.appList.push(appData);
                                                      console.log(this.appList[num],"\n\n");
                                                      
                                                      if(response.app.symptom2==null)
                                                          appData.sym= [response.app.symptom1];
                                                      else
                                                          appData.sym= [response.app.symptom1," "+response.app.symptom2];

                                                      num++;  
                                                    });
                            }
                          })
        .catch((response)=>{this.errorMessage="Fail";})
    
    if(browserRefresh){
      this.navbarService.updateDoctorLoginStatus(true);
    }

    if(this.currentDoctorData==null){
      this.router.navigate(['/login']);
    }   
  }

  onSubmit(buttonType): void{

    this.buttonClicked= String(buttonType);

    if(this.buttonClicked.substring(0,4)==="view"){
      this.appId = parseInt(this.buttonClicked.substring(4));
      console.log("update user "+this.appId);

      this.scheduleService.getPatientDetails(this.appId)
          .then((response)=>{ this.appPatientData=response;
                              console.log(this.appPatientData);})
          .catch((response)=>{this.errorMessage="Fail";})

    }

    if(this.buttonClicked.substring(0,6)==="accept"){
      this.appId = parseInt(this.buttonClicked.substring(6));
      console.log("delete user "+this.appId);

      this.scheduleService.getPatientDetails(this.appId)
          .then((response)=>{ this.appPatientData=response;
                              console.log(this.appPatientData);

          this.updateCureForm=this.fb.group(
          {
            'appid':[],
            'symptom1':[''],
            'symptom2':[null],
            'doctorid':[null],
            'days':[null],
            'dateofapp':[null],
            'status':['Pending']
          }),

          this.updateCureForm.patchValue({
          appid: this.appId,
          symptom1: this.appPatientData.app.symptom1,
          symptom2: this.appPatientData.app.symptom2,
          doctorid: this.appPatientData.app.doctorid,
          days: this.appPatientData.app.days,
          dateofapp: this.appPatientData.app.dateofapp,
          status: "Accepted"
      });
      
      this.loginService.updateAppointment(this.updateCureForm.value)
        .then((response) => { this.successMessage = "Success";
                              alert("Appointment for the patient has been accepted!");
                            })
        .catch((error) => { this.errorMessage = error.message;
                            alert("Could not accept appointment for the patient!");
                          });
      })
    }

    if(this.buttonClicked.substring(0,5)==="refer"){
      this.appId = parseInt(this.buttonClicked.substring(5));
      this.newAppId= this.appId;

    }
  }

  sendDoctorId(){

    this.newDocId= this.getForm.value.sdoc;
    console.log(this.newAppId);
    console.log(this.newDocId);

    this.scheduleService.getPatientDetails(this.newAppId)
        .then((response) => { this.patDetailUpdate=response;
                              console.log(this.patDetailUpdate.app.dateofapp); 
                            
                              this.appUpdateForm=this.fb.group(
                                {
                                  'appid':[],
                                  'symptom1':[null],
                                  'symptom2':[null],
                                  'doctorid':[null],
                                  'days':[null],
                                  'dateofapp':[null],
                                  'status':[null]
                                });
                          
                                this.appUpdateForm.patchValue({
                                  appid: this.patDetailUpdate.app.appid,
                                  symptom1: this.patDetailUpdate.app.symptom1,
                                  symptom2: this.patDetailUpdate.app.symptom2,
                                  doctorid: this.newDocId,
                                  days: this.patDetailUpdate.app.days,
                                  dateofapp: this.patDetailUpdate.app.dateofapp,
                                  status: "Pending"
                                });

                                
                                this.scheduleService.updateAppointment(this.appUpdateForm.value)
                                    .then((response) => { this.successMessage = "Success";
                                                          alert("Patient has successfully been refered to other doctor.");
                                                         })
                                    .catch((error) => { this.errorMessage = error.message;
                                                        alert("Could not refer patient to other doctor!");
                                                      });
                            })

        .catch((error) => { this.errorMessage = error.message;})
        window.location.reload;
    
  
  }

}
