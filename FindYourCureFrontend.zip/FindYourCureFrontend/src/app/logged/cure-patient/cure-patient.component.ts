import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavbarService } from '../../app.navbar.service';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { patientData } from '../../login/login.patientData';
import { browserRefresh } from '../../app.component';
import { ScheduleService } from '../schedule.service';
import { doctorData } from '../../login/login.doctorData';
import { LoginService } from '../../login/login.service';


@Component({
  selector: 'app-cure-patient',
  templateUrl: './cure-patient.component.html',
  styleUrls: ['./cure-patient.component.css']
})
export class CurePatientComponent implements OnInit {
  
  isLoggedAsPatient: boolean=false;
  private currentPatientData: patientData = new patientData();
  cureForm: FormGroup;
  patientAppIdUpdateForm: FormGroup;
  private getDocDiv: boolean = false;

  errorMessage:string;
  successMessage:string;
  TheSymptomList1:string[] = ["Cold","Chest Pain","Menopause","Skin Rashes","Diabetic Problems","Nausea","Persistent Fatigue and Weakness","Decrease in Urination","Blood in Urine or Stool"];
  TheSymptomList2:string[] = ["Cough","Heartburn","Missed Periods","Acne Problems","Thyroid Problems","Loose Motion","Easy Bleeding or Bruising","Swelling in Legs or Feet","Thickening/Lump under the Skin"];

  doctorList:doctorData[] = null;

  constructor( private router:Router,  private navbarService:NavbarService,
               private fb:FormBuilder, private scheduleService:ScheduleService,
               private updatePatientAppId: LoginService )
               
  {
    this.navbarService.getPatientLoginStatus().subscribe(status => this.isLoggedAsPatient = status);
  }

  ngOnInit() {
    this.currentPatientData=JSON.parse(localStorage.getItem("myPatientData"));

    if(browserRefresh){
      this.navbarService.updatePatientLoginStatus(true);
    }

    if(this.currentPatientData==null){
      this.router.navigate(['/login']);
    }  

    this.cureForm=this.fb.group(
      {
        'appid':[],
        'symptom1':['',[Validators.required]],
        'symptom2':['',[Validators.required]],
        'doctorid':['',[Validators.required]],
        'days':['',[Validators.required,Validators.min(1)]],
        'dateofapp':['',[Validators.required]],
        'status':['Pending']
      } 
    ),

    this.patientAppIdUpdateForm=this.fb.group(
      {
        'pid':[],
        'pname':[],
        'gender':[],
        'age':[],
        'annualinc':[],
        'histofill':[],
        'histofmeds':[],
        'email':[],
        'password':[],
        'app':[]
      }
    ),

    this.patientAppIdUpdateForm.patchValue({
      pid: this.currentPatientData.pid,
      pname: this.currentPatientData.pname,
      gender: this.currentPatientData.gender,
      age: this.currentPatientData.age,
      annualinc: this.currentPatientData.annualinc,
      histofill: this.currentPatientData.histofill,
      histofmeds: this.currentPatientData.histofmeds,
      email: this.currentPatientData.email,    
      password: this.currentPatientData.password
    });
  }

  onSubmit(buttonType): void{

    if(buttonType==="getDoc"){
      this.getDocDiv = true;
      this.scheduleService.getDoctorList(this.cureForm.value)
      .then((response)=>{this.doctorList=response;
      })
    }

    if(buttonType==="submit"){
      this.errorMessage=null;
      this.successMessage=null;

      this.scheduleService.scheduleAppointment(this.cureForm.value)
      .then((response)=>{this.successMessage="Success";
                         this.cureForm.value.appid=response.appid;
    
        if(this.currentPatientData.app.appid!=null){

            this.cureForm.patchValue({
              appid: this.currentPatientData.app.appid
            });

            this.updatePatientAppId.updateAppointment(this.cureForm.value)
                .then((response) => { this.successMessage = "Success";
                                    })
                .catch((error) => { this.errorMessage = "Failure";
                                  });
                alert("You cure has been appointed succesfully!");
        }

        else{

            this.patientAppIdUpdateForm.value.app = this.cureForm.value;   
            this.updatePatientAppId.updatePatient(this.patientAppIdUpdateForm.value)
                .then((response) => { this.successMessage = "Success";
                                    })
                .catch((error) => { this.errorMessage = "Failure";
                                  });
            alert("You cure has been appointed succesfully!");
            console.log(this.patientAppIdUpdateForm.value);
        }

        localStorage.setItem("myPatientData", JSON.stringify(this.patientAppIdUpdateForm.value));
      })
      .catch(
        response=>this.errorMessage="Failure"
      )  
    }

  }

}
