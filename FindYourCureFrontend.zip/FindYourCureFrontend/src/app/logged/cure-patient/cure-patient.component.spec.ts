import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CurePatientComponent } from './cure-patient.component';

describe('CurePatientComponent', () => {
  let component: CurePatientComponent;
  let fixture: ComponentFixture<CurePatientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CurePatientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CurePatientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
