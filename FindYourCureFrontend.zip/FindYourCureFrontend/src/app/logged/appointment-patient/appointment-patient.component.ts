import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavbarService } from '../../app.navbar.service';
import { browserRefresh } from '../../app.component';
import { patientData } from '../../login/login.patientData';
import { appointmentData } from '../../login/login.appointmentData';
import { FetchService } from '../../admin/fetch.service';
import { ScheduleService } from '../schedule.service';
import { doctorData } from '../../login/login.doctorData';

@Component({
  selector: 'app-appointment-patient',
  templateUrl: './appointment-patient.component.html',
  styleUrls: ['./appointment-patient.component.css']
})
export class AppointmentPatientComponent implements OnInit {

  isLoggedAsPatient: boolean=false;
  currentPatientData: patientData = new patientData();
  tempPatientData: patientData = new patientData();
  appointmentDetails: appointmentData = new appointmentData();
  newPatientData: patientData = new patientData();

  errorMessage:string;
  symptomList: string[]= [];
  doctorName: string;

  constructor(private router:Router,  private navbarService:NavbarService,
              private fetchServie: FetchService, private scheduleService: ScheduleService)
  {
    this.navbarService.getPatientLoginStatus().subscribe(status => this.isLoggedAsPatient = status);
  }

  ngOnInit() {

    this.currentPatientData = JSON.parse(localStorage.getItem("myPatientData"));

     this.fetchServie.fetchPatientId(this.currentPatientData.pid)
         .then((response)=>{ this.newPatientData=response;
                             
          this.appointmentDetails = this.newPatientData.app;
          console.log(this.appointmentDetails);
      
          if(this.appointmentDetails.symptom2==null)
            this.symptomList= [this.appointmentDetails.symptom1];
          else
            this.symptomList= [this.appointmentDetails.symptom1," "+this.appointmentDetails.symptom2];
      
          console.log(this.appointmentDetails.doctorid);
      
          this.fetchServie.fetchDoctorId(this.appointmentDetails.doctorid)
              .then((response)=>{this.doctorName=response.dname;
                                 console.log(this.doctorName);})
      
          console.log(this.symptomList);
        })

    if(browserRefresh){
      this.navbarService.updatePatientLoginStatus(true);
    }

    if(this.currentPatientData==null){
      this.router.navigate(['/login']);
    }
  }
}
