import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NavbarService } from '../../app.navbar.service';
import { Router } from '@angular/router';
import { browserRefresh } from '../../app.component';
import { doctorData } from '../../login/login.doctorData';
import { RegisterService } from '../../register/register.service';
import { PasswordValidator } from '../../register/register.validator';

@Component({
  selector: 'app-register-a-patient',
  templateUrl: './register-a-patient.component.html',
  styleUrls: ['./register-a-patient.component.css']
})
export class RegisterAPatientComponent implements OnInit {

  isLoggedAsDoctor: boolean=false;
  private currentDoctorData: doctorData = new doctorData();

  errorMessage:string;
  successMessage:string;
  TheGender:string[] = ["Male","Female"];
  patientRegisterForm : FormGroup;
  private id: number;

  constructor(private navbarService:NavbarService, private router:Router,
              private registerService:RegisterService, private fb:FormBuilder)
  {
    this.navbarService.getDoctorLoginStatus().subscribe(status => this.isLoggedAsDoctor = status);
  }

  ngOnInit() {

    this.patientRegisterForm=this.fb.group(
      {
        'pname':['',[Validators.required,Validators.pattern("[a-zA-Z ]+")]],
        'gender':['',[Validators.required]],
        'age':['',[Validators.required,Validators.min(1),Validators.max(99)]],
        'annualinc':['',[Validators.required]],
        'histofill':['',[Validators.required]],
        'histofmeds':['',[Validators.required]],
        'email':['',[Validators.required,Validators.email]],
        'password':['',[Validators.required,PasswordValidator.invalidPassword]],
        'appid':['']
      } 
    );

    this.currentDoctorData=JSON.parse(localStorage.getItem("myDoctorData"));

    if(browserRefresh){
      this.navbarService.updateDoctorLoginStatus(true);
    }

    if(this.currentDoctorData==null){
      this.router.navigate(['/login']);
    }  
  }

  registerPatient(){
    
    this.errorMessage=null;
    this.successMessage=null;
    this.registerService.registerPatient(this.patientRegisterForm.value)
    .then((response) => { this.successMessage = "Success";
                          this.id=response.patient.pid;
                          console.log(response.patient.pid);
                          alert("Patient has been registered successfully!");
                        })
    .catch((error) => { this.errorMessage = "Failure"; 
                          // alert("Could not register the patient!");
                      });
                      alert("Patient has been registered successfully!");
  }

}
