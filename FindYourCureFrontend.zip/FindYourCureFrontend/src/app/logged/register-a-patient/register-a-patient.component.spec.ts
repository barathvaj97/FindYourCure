import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterAPatientComponent } from './register-a-patient.component';

describe('RegisterAPatientComponent', () => {
  let component: RegisterAPatientComponent;
  let fixture: ComponentFixture<RegisterAPatientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegisterAPatientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterAPatientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
