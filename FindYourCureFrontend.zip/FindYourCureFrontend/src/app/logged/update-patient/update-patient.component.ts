import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { PasswordValidator } from '../../register/register.validator';
import { patientData } from '../../login/login.patientData';
import { LoginService } from '../../login/login.service';
import { NavbarService } from '../../app.navbar.service';
import { Router } from '@angular/router';
import { browserRefresh } from '../../app.component';

@Component({
  selector: 'app-update-patient',
  templateUrl: './update-patient.component.html',
  styleUrls: ['./update-patient.component.css']
})
export class UpdatePatientComponent implements OnInit {
  
  errorMessage:string;
  successMessage:string;
  TheGender:string[] = ["Male","Female"];
  patientUpdateForm : FormGroup;
  private currentPatientData: patientData = new patientData();
  isLoggedAsPatient: boolean = false;

  constructor(private updateService:LoginService, private fb:FormBuilder,
              private navbarService:NavbarService, private router:Router)
  {
      this.navbarService.getPatientLoginStatus().subscribe(status => this.isLoggedAsPatient = status);
  }

  ngOnInit() {

    this.patientUpdateForm=this.fb.group(
      {
        'pid':[],
        'pname':['',[Validators.required,Validators.pattern("[a-zA-Z ]+")]],
        'gender':['',[Validators.required]],
        'age':['',[Validators.required,Validators.min(1),Validators.max(99)]],
        'annualinc':['',[Validators.required]],
        'histofill':['',[Validators.required]],
        'histofmeds':['',[Validators.required]],
        'email':['',[Validators.required,Validators.email]],
        'password':['',[Validators.required,PasswordValidator.invalidPassword]],
        'appid':[]
      }
    );

    this.currentPatientData=JSON.parse(localStorage.getItem("myPatientData"));

    this.patientUpdateForm.patchValue({
      pid: this.currentPatientData.pid,
      pname: this.currentPatientData.pname,
      gender: this.currentPatientData.gender,
      age: this.currentPatientData.age,
      annualinc: this.currentPatientData.annualinc,
      histofill: this.currentPatientData.histofill,
      histofmeds: this.currentPatientData.histofmeds,
      email: this.currentPatientData.email,    
      password: this.currentPatientData.password,
      appid: this.currentPatientData.appid,
    });

    if(browserRefresh){
      this.navbarService.updatePatientLoginStatus(true);
    }

    if(this.currentPatientData==null){
      this.router.navigate(['/login']);
    }    
        
  }

  updatePatient(){  
    this.errorMessage=null;
    this.successMessage=null;

    this.updateService.updatePatient(this.patientUpdateForm.value)
                      .then((response) => { this.successMessage = "Success";
                                            // alert("Patient details has successfully been updated!");
                                          })
                      .catch((error) => { this.errorMessage = "Failure";
                                          // alert("Patient details could not be updated!");
                                        });
                                        alert("Patient details has successfully been updated!");
  }

}
