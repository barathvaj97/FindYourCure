import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable()
export class NavbarService {

  private isLoggedAsPatient = new Subject<boolean>();
  private isLoggedAsDoctor = new Subject<boolean>();
  private isLoggedAsAdmin = new Subject<boolean>();

  constructor() {
    this.isLoggedAsPatient.next(false);
    this.isLoggedAsDoctor.next(false);
    this.isLoggedAsAdmin.next(false);
  }

  getPatientLoginStatus() {
    return this.isLoggedAsPatient;
  }

  updatePatientLoginStatus(status: boolean) {
    this.isLoggedAsPatient.next(status);
  }

  getDoctorLoginStatus() {
    return this.isLoggedAsDoctor;
  }

  updateDoctorLoginStatus(status: boolean) {
    this.isLoggedAsDoctor.next(status);
  }

  getAdminLoginStatus() {
    return this.isLoggedAsAdmin;
  }

  updateAdminLoginStatus(status: boolean) {
    this.isLoggedAsAdmin.next(status);
  }

}
