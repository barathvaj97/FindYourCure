import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule, Router } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { PatientComponent } from './logged/patient/patient.component';
import { DoctorComponent } from './logged/doctor/doctor.component';
import { AppComponent } from './app.component';
import { AboutComponent } from './about/about.component';
import { UpdatePatientComponent } from './logged/update-patient/update-patient.component';
import { UpdateDoctorComponent } from './logged/update-doctor/update-doctor.component';
import { CurePatientComponent } from './logged/cure-patient/cure-patient.component';
import { AppointmentDoctorComponent } from './logged/appointment-doctor/appointment-doctor.component';
import { RegisterAPatientComponent } from './logged/register-a-patient/register-a-patient.component';
import { AppointmentPatientComponent } from './logged/appointment-patient/appointment-patient.component';
import { AdminLoginComponent } from './admin/admin-login/admin-login.component';
import { AdminPortalComponent } from './admin/admin-portal/admin-portal.component';
import { ViewPatientComponent } from './admin/view-patient/view-patient.component';
import { ViewDoctorComponent } from './admin/view-doctor/view-doctor.component';
import { RegisterUserComponent } from './admin/register-user/register-user.component';
import { PatientUpdateComponent } from './admin/patient-update/patient-update.component';
import { DoctorUpdateComponent } from './admin/doctor-update/doctor-update.component';

const routes: Routes = [
 
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component:HomeComponent },  
  { path: 'register', component: RegisterComponent},
  { path: 'about', component: AboutComponent},
  { path: 'admin_login', component:AdminLoginComponent },
  { path: 'admin_portal', component:AdminPortalComponent },
  { path: 'view_patient', component:ViewPatientComponent },
  { path: 'view_doctor', component:ViewDoctorComponent },
  { path: 'register_user', component:RegisterUserComponent },
  { path: 'login', component:LoginComponent },
  { path: 'patient/:pid', component: PatientComponent},
  { path: 'update_patient', component: UpdatePatientComponent},
  { path: 'findyourcure', component: CurePatientComponent},
  { path: 'check#appointment', component: AppointmentPatientComponent},
  { path: 'doctor/:did', component: DoctorComponent},
  { path: 'update_doctor', component: UpdateDoctorComponent},
  { path: 'manage#appointment', component: AppointmentDoctorComponent},
  { path: 'register_a_patient', component: RegisterAPatientComponent},
  { path: 'patient_update', component: PatientUpdateComponent},
  { path: 'doctor_update', component: DoctorUpdateComponent}
];


@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
    exports: [ RouterModule ]
    
  
})
export class AppRoutingModule { 

}