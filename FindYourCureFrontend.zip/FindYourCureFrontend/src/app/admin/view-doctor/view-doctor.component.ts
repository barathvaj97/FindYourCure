import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { browserRefresh } from '../../app.component';
import { NavbarService } from '../../app.navbar.service';
import { Router } from '@angular/router';
import { FetchService } from '../fetch.service';
import { doctorData } from '../../login/login.doctorData';

@Component({
  selector: 'app-view-doctor',
  templateUrl: './view-doctor.component.html',
  styleUrls: ['./view-doctor.component.css']
})
export class ViewDoctorComponent implements OnInit {

  
  private doctorId: number;
  private buttonClicked: String;
  private logAdminData: String;
  allDoctorList:doctorData[] = null;
  successMessage: string;
  errorMessage: string;

  constructor(private navbarService: NavbarService, private router: Router,
              private fetchService: FetchService )
  { }

  ngOnInit() {
    
    this.logAdminData=localStorage.getItem("myAdminData");

    this.fetchService.fetchDoctors()
        .then((response)=>{this.allDoctorList=response; 
          console.log(this.allDoctorList); 
        });

    if(browserRefresh){
      this.navbarService.updateAdminLoginStatus(true);
    }

    if(this.logAdminData==null){
      this.router.navigate(['/admin_login']);
    }      
  }

  onSubmit(buttonType): void{

    this.buttonClicked= String(buttonType);

    if(this.buttonClicked.substring(0,6)==="update"){
      this.doctorId = parseInt(this.buttonClicked.substring(6));
      console.log("update user "+this.doctorId);

      localStorage.setItem("myDoctorId", this.buttonClicked.substring(6));
      this.router.navigate(['/doctor_update']);
    }

    if(this.buttonClicked.substring(0,6)==="delete"){
      this.doctorId = parseInt(this.buttonClicked.substring(6));
      console.log("delete user "+this.doctorId);

      alert("Doctor with ID: "+this.doctorId+" will be removed permanently!");
      this.fetchService.deleteDoctor(this.doctorId);
    }
    window.location.reload();
  }

}
