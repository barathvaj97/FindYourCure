import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { browserRefresh } from '../../app.component';
import { NavbarService } from '../../app.navbar.service';
import { Router } from '@angular/router';
import { RegisterService } from '../../register/register.service';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {

  private logAdminData: String;
  errorMessage:string;
  successMessage:string;
  TheGender:string[] = ["Male","Female"];
  TheList:string[] = ["Pediatrition","Cardiologist","Psychiatrist","Gynocologist"];
  typePatient:boolean = false;
  typeDoctor:boolean = false;
  patientRegisterForm : FormGroup;
  doctorRegisterForm : FormGroup;

  constructor(private navbarService: NavbarService, private router: Router,
              private registerService:RegisterService, private fb:FormBuilder)
  { }

  choicePatient(){
    this.typePatient = true;
    this.typeDoctor = false;
  }

  choiceDoctor(){
    this.typePatient = false;
    this.typeDoctor = true;
  }

  ngOnInit() {

    this.patientRegisterForm=this.fb.group(
      {
        'pname':['',[Validators.required,Validators.pattern("[a-zA-Z ]+")]],
        'gender':['',[Validators.required]],
        'age':['',[Validators.required,Validators.min(1),Validators.max(99)]],
        'annualinc':['',[Validators.required]],
        'histofill':['',[Validators.required]],
        'histofmeds':['',[Validators.required]],
        'email':['',[Validators.required,Validators.email]],
        'password':['',[Validators.required]],
        'appid':['']
      } 
    ),

    this.doctorRegisterForm=this.fb.group(
      {
        'dname':['',[Validators.required,Validators.pattern("[a-zA-Z ]+")]],
        'yrsofexp':['',[Validators.required,Validators.min(1),Validators.max(99)]],
        'visithours':['',[Validators.required]],
        'visithoursend':['',[Validators.required]],
        'fee':['',[Validators.required]],
        'spc':['',[Validators.required]],
        'email':['',[Validators.required,Validators.email]],
        'password':['',[Validators.required]]
      }
    );

    this.logAdminData=localStorage.getItem("myAdminData");

    if(browserRefresh){
      this.navbarService.updateAdminLoginStatus(true);
    }

    if(this.logAdminData==null){
      this.router.navigate(['/admin_login']);
    }  
  }

  registerPatient(){
    
    this.errorMessage=null;
    this.successMessage=null;
    this.registerService.registerPatient(this.patientRegisterForm.value)
    .then(
      response=>this.successMessage="Success"
      
    )
    .catch(
      response=>this.errorMessage="Failure"
    )
  }

  registerDoctor(){
    
    this.errorMessage=null;
    this.successMessage=null;
    this.registerService.registerDoctor(this.doctorRegisterForm.value)
    .then(
      response=>this.successMessage="Success"
      
    )
    .catch(
      response=>this.errorMessage="Failure"
    )
  }

}
