import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormsModule, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { doctorData } from '../../login/login.doctorData';
import { LoginService } from '../../login/login.service';
import { NavbarService } from '../../app.navbar.service';
import { Router } from '@angular/router';
import { browserRefresh } from '../../app.component';
import { FetchService } from '../fetch.service';

@Component({
  selector: 'app-doctor-update',
  templateUrl: './doctor-update.component.html',
  styleUrls: ['./doctor-update.component.css']
})
export class DoctorUpdateComponent implements OnInit {

  errorMessage:string;
  successMessage:string;
  TheList:string[] = ["pediatrition","cardiologist","psychiatrist","gynocologist","ent"];
  doctorUpdateForm : FormGroup;
  private doctorDetails: doctorData = new doctorData();
  private doctorId: string;
  isLoggedAsAdmin: boolean = false;

  constructor(private updateService:LoginService, private fb:FormBuilder,
              private navbarService:NavbarService, private router:Router,
              private fetchService: FetchService)
  {
    this.navbarService.getPatientLoginStatus().subscribe(status => this.isLoggedAsAdmin = status);
  }

  ngOnInit() {

    this.doctorUpdateForm=this.fb.group(
      {
        'did':[],
        'dname':['',[Validators.required,Validators.pattern("[a-zA-Z ]+")]],
        'yrsofexp':['',[Validators.required,Validators.min(1),Validators.max(99)]],
        'visithours':['',[Validators.required]],
        'visithoursend':['',[Validators.required]],
        'fee':['',[Validators.required]],
        'spc':['',[Validators.required]],
        'email':['',[Validators.required,Validators.email]],
        'password':['',[Validators.required]]
      }
    );

    this.doctorId=localStorage.getItem("myDoctorId");
    console.log(this.doctorId);

    this.fetchService.fetchDoctorId(this.doctorId)
        .then((response) => { this.doctorDetails = response;
                              this.successMessage = "Success";

                              this.doctorUpdateForm.patchValue({
                                did: this.doctorDetails.did,
                                dname: this.doctorDetails.dname,
                                yrsofexp: this.doctorDetails.yrsofexp,
                                visithours: this.doctorDetails.visithours,
                                visithoursend: this.doctorDetails.visithoursend,
                                fee: this.doctorDetails.fee,
                                spc: this.doctorDetails.spc,
                                email: this.doctorDetails.email,                            
                                password: this.doctorDetails.password,
                              });
        })
        .catch((error) => { this.errorMessage = error.message;
        });

        if(browserRefresh){
          this.navbarService.updateAdminLoginStatus(true);
        }
    }

    updateDoctor(){  
      this.errorMessage=null;
      this.successMessage=null;
  
      this.updateService.updateDoctor(this.doctorUpdateForm.value)
                        .then(response=>this.successMessage="Success")
                        .catch(response=>this.errorMessage="Failure")
    }
    
    ngDestroy() {
      localStorage.removeItem("myDoctorId");
    }

}
