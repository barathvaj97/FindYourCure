import { Component, OnInit } from '@angular/core';
import { NavbarService } from '../../app.navbar.service';
import { browserRefresh } from '../../app.component';
import { Router } from '@angular/router';
import { FetchService } from '../fetch.service';
import { patientData } from '../../login/login.patientData';

@Component({
  selector: 'app-view-patient',
  templateUrl: './view-patient.component.html',
  styleUrls: ['./view-patient.component.css']
})
export class ViewPatientComponent implements OnInit {

  private patientId: number;
  private buttonClicked: String;
  private logAdminData: String;
  allPatientList:patientData[] = null;
  successMessage: string;
  errorMessage: string;

  constructor(private navbarService: NavbarService, private router: Router,
              private fetchService: FetchService)
  { }

  ngOnInit() {

    this.logAdminData=localStorage.getItem("myAdminData");

    this.fetchService.fetchPatients()
        .then((response)=>{this.allPatientList=response; 
          console.log(this.allPatientList); 
        });

    if(browserRefresh){
      this.navbarService.updateAdminLoginStatus(true);
    }

    if(this.logAdminData==null){
      this.router.navigate(['/admin_login']);
    }  
    
  }

  onSubmit(buttonType): void{

    this.buttonClicked= String(buttonType);

    if(this.buttonClicked.substring(0,6)==="update"){
      this.patientId = parseInt(this.buttonClicked.substring(6));
      console.log("update user "+this.patientId);

      localStorage.setItem("myPatientId", this.buttonClicked.substring(6));
      this.router.navigate(['/patient_update']);
    }

    if(this.buttonClicked.substring(0,6)==="delete"){
      this.patientId = parseInt(this.buttonClicked.substring(6));
      console.log("delete user "+this.patientId);

      alert("Patient with ID: "+this.patientId+"will be removed permanently!");
      this.fetchService.deletePatient(this.patientId)
        .then((response) => { this.successMessage = "Success";})
        .catch((error) => { this.errorMessage = error.message;});
    }
  } 

}
