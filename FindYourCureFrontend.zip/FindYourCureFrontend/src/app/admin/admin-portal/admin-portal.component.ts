import { Component, OnInit } from '@angular/core';
import { browserRefresh } from '../../app.component';
import { NavbarService } from '../../app.navbar.service';
import { Router } from '@angular/router';
import { PlatformLocation } from '@angular/common';

@Component({
  selector: 'app-admin-portal',
  templateUrl: './admin-portal.component.html',
  styleUrls: ['./admin-portal.component.css']
})
export class AdminPortalComponent implements OnInit {

  private logAdminData: String;

  constructor(private navbarService: NavbarService, private router: Router, 
              private location: PlatformLocation)
  {
      location.onPopState(() => {
          if( this.router.url=="/admin_login" )
          {
              localStorage.removeItem('myAdminData');
          }
      }); 
  }

  ngOnInit() {

    this.logAdminData=localStorage.getItem("myAdminData");

    if(browserRefresh){
      this.navbarService.updateAdminLoginStatus(true);
    }

    if(this.logAdminData==null){
      this.router.navigate(['/admin_login']);
    }      
  }

}
