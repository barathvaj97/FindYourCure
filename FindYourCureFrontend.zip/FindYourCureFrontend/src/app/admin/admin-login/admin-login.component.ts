import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, FormGroup, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { NavbarService } from '../../app.navbar.service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  errorMessage:string = null;
  successMessage:string = null;
  adminLoginForm : FormGroup;
  isLoggedAsAdmin = false;

  constructor(private fb:FormBuilder, private router:Router, private navbarService: NavbarService)
  {
    this.navbarService.getAdminLoginStatus().subscribe(status => this.isLoggedAsAdmin = status);
  }

  ngOnInit() {
    this.navbarService.updateAdminLoginStatus(false);

    this.adminLoginForm=this.fb.group(
      {
        'adminid':['',[Validators.required]],
        'password':['',[Validators.required]]
      } 
    )
  }

  loginAdmin() {
    
    if(this.adminLoginForm.value.adminid==="admin" && this.adminLoginForm.value.password==="admin"){

      this.navbarService.updateAdminLoginStatus(true);
      localStorage.setItem("myAdminData", "admin");
      this.router.navigate(['/admin_portal']);
    }   
  }

}
