import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormsModule, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { patientData } from '../../login/login.patientData';
import { LoginService } from '../../login/login.service';
import { NavbarService } from '../../app.navbar.service';
import { Router } from '@angular/router';
import { browserRefresh } from '../../app.component';
import { FetchService } from '../fetch.service';

@Component({
  selector: 'app-patient-update',
  templateUrl: './patient-update.component.html',
  styleUrls: ['./patient-update.component.css']
})
export class PatientUpdateComponent implements OnInit {

  errorMessage:string;
  successMessage:string;
  TheGender:string[] = ["Male","Female"];
  patientUpdateForm : FormGroup;
  private patientDetails: patientData = new patientData();
  private patientId: string;
  isLoggedAsAdmin: boolean = false;

  constructor(private updateService:LoginService, private fb:FormBuilder,
              private navbarService:NavbarService, private router:Router,
              private fetchService: FetchService)
  {
    this.navbarService.getPatientLoginStatus().subscribe(status => this.isLoggedAsAdmin = status);
  }

  ngOnInit() {

    this.patientUpdateForm=this.fb.group(
      {
        'pid':[],
        'pname':['',[Validators.required,Validators.pattern("[a-zA-Z ]+")]],
        'gender':['',[Validators.required]],
        'age':['',[Validators.required,Validators.min(1),Validators.max(99)]],
        'annualinc':['',[Validators.required]],
        'histofill':['',[Validators.required]],
        'histofmeds':['',[Validators.required]],
        'email':['',[Validators.required,Validators.email]],
        'password':['',[Validators.required]],
        'appid':[]
      }
    );

    this.patientId=localStorage.getItem("myPatientId");
    console.log(this.patientId);

    this.fetchService.fetchPatientId(this.patientId)
        .then((response) => { this.patientDetails = response;
                              this.successMessage = "Success";

                              this.patientUpdateForm.patchValue({
                                pid: this.patientDetails.pid,
                                pname: this.patientDetails.pname,
                                gender: this.patientDetails.gender,
                                age: this.patientDetails.age,
                                annualinc: this.patientDetails.annualinc,
                                histofill: this.patientDetails.histofill,
                                histofmeds: this.patientDetails.histofmeds,
                                email: this.patientDetails.email,    
                                password: this.patientDetails.password,
                                appid: this.patientDetails.appid,
                              });
        })
        .catch((error) => { this.errorMessage = error.message;
        });

    
    if(browserRefresh){
      this.navbarService.updateAdminLoginStatus(true);
    }
  }

  updatePatient(){  
    this.errorMessage=null;
    this.successMessage=null;

    this.updateService.updatePatient(this.patientUpdateForm.value)
                      .then(response=>this.successMessage="Success")
                      .catch(response=>this.errorMessage="Failure")
  }
  
  ngDestroy() {
    localStorage.removeItem("myPatientId");
  }

}
