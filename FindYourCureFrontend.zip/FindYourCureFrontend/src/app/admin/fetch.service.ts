import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { patientData } from '../login/login.patientData';
import { doctorData } from '../login/login.doctorData';

@Injectable()
export class FetchService {

  constructor(private http: Http) { }

  fetchPatients() :Promise<patientData[]>{
    return this.http
    .get("http://localhost:8765/FindYourCureBackend/FindYourCureAPI/showAllPatients")
    .toPromise()
    .then(response => response.json() as patientData[])
    .catch(this.errorHandler);
  }

  fetchPatientId(pid:any) :Promise<patientData>{
    return this.http
    .get("http://localhost:8765/FindYourCureBackend/FindYourCureAPI/displayPatient/"+pid)
    .toPromise()
    .then(response => response.json() as patientData)
    .catch(this.errorHandler);
  }

  fetchDoctors() :Promise<doctorData[]>{
    return this.http
    .get("http://localhost:8765/FindYourCureBackend/FindYourCureAPI/showAllDoctors")
    .toPromise()
    .then(response => response.json() as doctorData[])
    .catch(this.errorHandler);
  }

  fetchDoctorId(did:any) : Promise<doctorData> {
    return this.http
    .post("http://localhost:8765/FindYourCureBackend/FindYourCureAPI/getDoc/"+did, did)
    .toPromise()
    .then(response => response.json() as doctorData)
    .catch(this.errorHandler);
  }

  deletePatient(pid:any) : Promise<doctorData> {
    return this.http
    .delete("http://localhost:8765/FindYourCureBackend/FindYourCureAPI/deletePatient/"+pid)
    .toPromise()
    .then(response => response.json() as any)
    .catch(this.errorHandler);
  }

  deleteDoctor(did:any) : Promise<doctorData> {
    return this.http
    .delete("http://localhost:8765/FindYourCureBackend/FindYourCureAPI/deleteDoctor/"+did)
    .toPromise()
    .then(response => response.json() as any)
    .catch(this.errorHandler);
  }

  errorHandler(error){
    return Promise.reject(error.json())
  }

}
