import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import "rxjs/add/operator/toPromise";

@Injectable()
export class RegisterService {

  constructor(private http:Http) { }

  registerPatient(data) :Promise<any>{
    return this.http
    .post("http://localhost:8765/FindYourCureBackend/FindYourCureAPI/addPatient",data)
    .toPromise()
    .then(response => response.json() as any)
    .catch(this.errorHandler);
  }

  registerDoctor(data) :Promise<any>{
    return this.http
    .post("http://localhost:8765/FindYourCureBackend/FindYourCureAPI/addDoctor",data)
    .toPromise()
    .then(response => response.json() as any)
    .catch(this.errorHandler);
  }

  errorHandler(error){
    return Promise.reject(error.json())
  }
  
}
