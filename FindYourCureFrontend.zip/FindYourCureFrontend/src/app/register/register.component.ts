import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RegisterService } from './register.service';
import { PasswordValidator } from './register.validator';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  errorMessage:string;
  successMessage:string;
  TheGender:string[] = ["Male","Female"];
  TheList:string[] = ["Pediatrition","Cardiologist","Psychiatrist","Gynocologist"];
  typePatient:boolean = false;
  typeDoctor:boolean = false;
  patientRegisterForm : FormGroup;
  doctorRegisterForm : FormGroup;

  
  constructor(private registerService:RegisterService, private fb:FormBuilder)
  { }

  choicePatient(){
    this.typePatient = true;
    this.typeDoctor = false;
  }

  choiceDoctor(){
    this.typePatient = false;
    this.typeDoctor = true;
  }

  ngOnInit() {
   
    this.patientRegisterForm=this.fb.group(
      {
        'pname':['',[Validators.required,Validators.pattern("[a-zA-Z ]+")]],
        'gender':['',[Validators.required]],
        'age':['',[Validators.required,Validators.min(1),Validators.max(99)]],
        'annualinc':['',[Validators.required]],
        'histofill':['',[Validators.required]],
        'histofmeds':['',[Validators.required]],
        'email':['',[Validators.required,Validators.email]],
        'password':['',[Validators.required,PasswordValidator.invalidPassword]],
        'appid':['']
      } 
    ),

    this.doctorRegisterForm=this.fb.group(
      {
        'dname':['',[Validators.required,Validators.pattern("[a-zA-Z ]+")]],
        'yrsofexp':['',[Validators.required,Validators.min(1),Validators.max(99)]],
        'visithours':['',[Validators.required]],
        'visithoursend':['',[Validators.required]],
        'fee':['',[Validators.required]],
        'spc':['',[Validators.required]],
        'email':['',[Validators.required,Validators.email]],
        'password':['',[Validators.required,PasswordValidator.invalidPassword]]
      }
    )
  }

  registerPatient(){
    
    this.errorMessage=null;
    this.successMessage=null;
    this.registerService.registerPatient(this.patientRegisterForm.value)
    .then(
      response=>this.successMessage="Success"
      
    )
    .catch(
      response=>this.errorMessage="Failure"
    )
    alert("Patient has been registered successfully!");
  }

  registerDoctor(){
    
    this.errorMessage=null;
    this.successMessage=null;
    this.registerService.registerDoctor(this.doctorRegisterForm.value)
    .then(
      response=>this.successMessage="Success"
      
    )
    .catch(
      response=>this.errorMessage="Failure"
    )

    alert("Doctor has been registered successfully!");
  }

}
