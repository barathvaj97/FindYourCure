import { AbstractControl, ValidationErrors } from "@angular/forms";
import { isNull } from "util";

export class PasswordValidator {
  static invalidPassword(control : AbstractControl){

    let inputValue:string = control.value as string;
    if(inputValue.length<8 ){
        return {"invalidPassword":true};    
    }

    var regex1 = "[0-9]";
    var regex2 = "[a-z]";
    var regex3 = "[A-Z]";
    var regex4 = "[~`!@#$%^&*\\\/\"\']";
    var regex5 = "[ ]";

    if(inputValue.match(regex1)==null || inputValue.match(regex2)==null || inputValue.match(regex4)==null || inputValue.match(regex3)==null || inputValue.match(regex5)!=null)
        return {"invalidPassword":true};

    return null;
}
}
