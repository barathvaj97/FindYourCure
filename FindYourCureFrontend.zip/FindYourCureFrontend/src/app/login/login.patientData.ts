import { appointmentData } from "./login.appointmentData";

export class patientData{

    pid: number;
    pname: string;
    gender: string;
    age: number;
    annualinc: number;
    histofill: string;
    histofmeds: string;
    email: string;
    password: string;
    appid: number;
    app: appointmentData;
}