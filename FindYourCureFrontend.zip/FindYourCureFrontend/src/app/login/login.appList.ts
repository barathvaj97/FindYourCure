import { appointmentData } from "./login.appointmentData";
import { patientData } from "./login.patientData";

export class AppList{

    itr: number;
    sym: string[];
    pat: patientData;
}