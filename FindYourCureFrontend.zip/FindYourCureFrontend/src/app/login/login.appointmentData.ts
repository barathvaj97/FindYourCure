export class appointmentData{

    appid: number;
    symptom1: string;
    symptom2: string;
    symptom3: string;
    doctorid: number;
    days: number;
    dateofapp: Date;
    status: string;
}