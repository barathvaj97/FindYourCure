export class doctorData{
    
    did: number;
    dname: string;
    yrsofexp: number;
    visithours: string;
    visithoursend: string;
    fee: number;
    spc: string;
    email: string;
    password: string;
}