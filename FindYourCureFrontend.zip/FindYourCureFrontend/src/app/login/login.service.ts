import { Injectable, EventEmitter } from '@angular/core';
import { Http } from '@angular/http';
import "rxjs/add/operator/toPromise";

@Injectable()
export class LoginService {
  link1: Array<{ text: string, path: string }> = [];
  link2: Array<{ text: string, path: string }> = [];
  constructor(private http:Http) { 
   
  }

  onMainEvent: EventEmitter<any> = new EventEmitter();

  getPatientData(data) : Promise<any> {
    return this.http
    .post("http://localhost:8765/FindYourCureBackend/FindYourCureAPI/loginPatient",data)
    .toPromise()
    .then(response => response.json() as any)
    .catch(this.errorHandler);
  }

  getDoctorData(data) : Promise<any> {
    return this.http
    .post("http://localhost:8765/FindYourCureBackend/FindYourCureAPI/loginDoctor",data)
    .toPromise()
    .then(response => response.json() as any)
    .catch(this.errorHandler);
  }

  updatePatient(data) :Promise<any>{
    return this.http
    .post("http://localhost:8765/FindYourCureBackend/FindYourCureAPI/updatePatient",data)
    .toPromise()
    .then(response => response.json() as any)
    .catch(this.errorHandler);
  }

  updateDoctor(data) :Promise<any>{
    return this.http
    .post("http://localhost:8765/FindYourCureBackend/FindYourCureAPI/updateDoctor",data)
    .toPromise()
    .then(response => response.json() as any)
    .catch(this.errorHandler);
  }

  updateAppointment(data) :Promise<any>{
    return this.http
    .post("http://localhost:8765/FindYourCureBackend/FindYourCureAPI/updateAppointment",data)
    .toPromise()
    .then(response => response.json() as any)
    .catch(this.errorHandler);
  }

  errorHandler(error){
    return Promise.reject(error.json())
  }

  

}
