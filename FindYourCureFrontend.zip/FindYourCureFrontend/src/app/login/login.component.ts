import { Component, OnInit } from '@angular/core';
import { FormsModule, FormBuilder, FormGroup, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from './login.service';
import { NavbarService } from '../app.navbar.service';
import { patientData } from './login.patientData';
import { doctorData } from './login.doctorData';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  errorMessage:string;
  successMessage:string;
  typePatient:boolean = false;
  typeDoctor:boolean = false;
  patientLoginForm : FormGroup;
  doctorLoginForm : FormGroup;
  myPatient:patientData;
  myDoctor:doctorData;

  isLoggedAsPatient = false;
  isLoggedAsDoctor = false;

  constructor(private loginService:LoginService, private fb:FormBuilder,
              private router:Router, private navbarService: NavbarService)
  {  
    this.navbarService.getPatientLoginStatus().subscribe(status => this.isLoggedAsPatient = status);
    this.navbarService.getDoctorLoginStatus().subscribe(status => this.isLoggedAsDoctor = status);  
  }

  choicePatient(){
    this.typePatient = true;
    this.typeDoctor = false;
  }

  choiceDoctor(){
    this.typePatient = false;
    this.typeDoctor = true;
  }

  ngOnInit() {
    this.navbarService.updatePatientLoginStatus(false);
    this.navbarService.updateDoctorLoginStatus(false);

    this.patientLoginForm=this.fb.group(
      {
        'pid':['',[Validators.required,Validators.pattern("[1-9][0-9]{2}")]],
        'password':['',[Validators.required]]
      } 
    ),

    this.doctorLoginForm=this.fb.group(
      {
        'did':['',[Validators.required,Validators.pattern("[1-9][0-9]{3}")]],
        'password':['',[Validators.required]],
      }
    )
  }

  loginPatient() {
    this.errorMessage=null;
    this.successMessage=null;
    this.myPatient=null;

    this.loginService.getPatientData(this.patientLoginForm.value)
                     .then((response)=>{this.myPatient=response;
                          if(this.myPatient!=null)
                          {
                              localStorage.setItem("myPatientData", JSON.stringify(this.myPatient));
                              this.router.navigate(['/patient', this.myPatient.pid]);
                              this.navbarService.updatePatientLoginStatus(true);
                          }
                      })
                     .catch(response=>this.errorMessage=response.message);
    
  }

  loginDoctor() {
    this.errorMessage=null;
    this.successMessage=null;
    this.myDoctor=null;

    this.loginService.getDoctorData(this.doctorLoginForm.value)
                     .then((response)=>{this.myDoctor=response;
                          if(this.myDoctor!=null)
                          {
                              localStorage.setItem("myDoctorData", JSON.stringify(this.myDoctor));
                              this.router.navigate(['/doctor', this.myDoctor.did]);
                              this.navbarService.updateDoctorLoginStatus(true);
                          }
                      })
                     .catch(response=>this.errorMessage=response.message);
  }

}
