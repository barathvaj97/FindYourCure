var regex1 = "[0-9]";
var regex2 = "[a-z]";
var regex3 = "[A-Z]";
var regex4 = "[~`!@#$%^&*\\\/\"\']";
var regex5 = "[ ]";

let str:string = "abc456 XYZ*&%#$^";

console.log(str.match(regex4));