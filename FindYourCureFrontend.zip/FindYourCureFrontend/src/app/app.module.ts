import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpModule } from "@angular/http";


import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { RegisterService } from './register/register.service';
import { AppRoutingModule } from './app-routing.module';
import { LoginService } from './login/login.service';
import { DoctorComponent } from './logged/doctor/doctor.component';
import { PatientComponent } from './logged/patient/patient.component';
import { AboutComponent } from './about/about.component';
import { NavbarService } from './app.navbar.service';
import { UpdateDoctorComponent } from './logged/update-doctor/update-doctor.component';
import { UpdatePatientComponent } from './logged/update-patient/update-patient.component';
import { CurePatientComponent } from './logged/cure-patient/cure-patient.component';
import { AppointmentDoctorComponent } from './logged/appointment-doctor/appointment-doctor.component';
import { RegisterAPatientComponent } from './logged/register-a-patient/register-a-patient.component';
import { TimeFormatPipe } from './logged/time-format.pipe';
import { HomeComponent } from './home/home.component';
import { ScheduleService } from './logged/schedule.service';
import { AppointmentPatientComponent } from './logged/appointment-patient/appointment-patient.component';
import { AdminLoginComponent } from './admin/admin-login/admin-login.component';
import { AdminPortalComponent } from './admin/admin-portal/admin-portal.component';
import { ViewPatientComponent } from './admin/view-patient/view-patient.component';
import { ViewDoctorComponent } from './admin/view-doctor/view-doctor.component';
import { RegisterUserComponent } from './admin/register-user/register-user.component';
import { FetchService } from './admin/fetch.service';
import { PatientUpdateComponent } from './admin/patient-update/patient-update.component';
import { DoctorUpdateComponent } from './admin/doctor-update/doctor-update.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    DoctorComponent,
    PatientComponent,
    AboutComponent,
    UpdateDoctorComponent,
    UpdatePatientComponent,
    CurePatientComponent,
    AppointmentDoctorComponent,
    RegisterAPatientComponent,
    TimeFormatPipe,
    HomeComponent,
    AppointmentPatientComponent,
    AdminLoginComponent,
    AdminPortalComponent,
    ViewPatientComponent,
    ViewDoctorComponent,
    RegisterUserComponent,
    PatientUpdateComponent,
    DoctorUpdateComponent,
  ],

  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    AppRoutingModule
  ],

  providers: [RegisterService, LoginService, NavbarService, ScheduleService, FetchService],
  
  bootstrap: [AppComponent]
})
export class AppModule { }
