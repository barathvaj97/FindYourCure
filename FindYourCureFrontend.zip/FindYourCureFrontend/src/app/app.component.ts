import { Component, ChangeDetectorRef } from '@angular/core';
import { LoginComponent } from './login/login.component';
import { NavbarService } from './app.navbar.service';
import { Router, NavigationStart } from '@angular/router';
import { Subscription } from 'rxjs';
import { patientData } from './login/login.patientData';
import { doctorData } from './login/login.doctorData';

export let browserRefresh = false;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'FindYourCure';
  isLoggedAsPatient = false;
  isLoggedAsDoctor = false;
  isLoggedAsAdmin = false;
  private logPatientData: patientData = new patientData();
  private logDoctorData: doctorData = new doctorData();
  subscription: Subscription;

  constructor(private navbarService: NavbarService, private router:Router,
              private cdr: ChangeDetectorRef)
  {
    this.subscription = router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        browserRefresh = !router.navigated;
        this.logPatientData=JSON.parse(localStorage.getItem("myPatientData"));
        this.logDoctorData=JSON.parse(localStorage.getItem("myDoctorData"));
      }
    });
  }

  ngOnInit() {
    this.navbarService.getPatientLoginStatus().subscribe(status => this.isLoggedAsPatient = status);
    this.navbarService.getDoctorLoginStatus().subscribe(status => this.isLoggedAsDoctor = status);
    this.navbarService.getAdminLoginStatus().subscribe(status => this.isLoggedAsAdmin = status);
  }

  ngAfterViewChecked(){
    this.cdr.detectChanges();
  }

  logout() {   
    this.navbarService.updatePatientLoginStatus(false);
    this.navbarService.updateDoctorLoginStatus(false); 
    if(this.isLoggedAsAdmin){
        this.navbarService.updateAdminLoginStatus(false);
        localStorage.removeItem('myAdminData');
        this.router.navigate(['/admin_login']);
    }
    localStorage.removeItem('myPatientData');
    localStorage.removeItem('myDoctorData');
  }

}
